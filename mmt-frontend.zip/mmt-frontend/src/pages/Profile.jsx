export default function Profile() {
  return (
    <div className="page-wrapper">
      <h1>Your Profile</h1>
      <p>Show user details, loyalty level, recent trips etc.</p>
    </div>
  );
}
