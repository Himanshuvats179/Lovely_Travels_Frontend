import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

export default function OauthSuccess({ onLogin }) {
  const navigate = useNavigate();

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);

    const accessToken = params.get("accessToken");
    const refreshToken = params.get("refreshToken");
    const fullName = params.get("fullName");
    const email = params.get("email");
    const pictureUrl = params.get("pictureUrl");

    if (!accessToken) {
      navigate("/");
      return;
    }

    localStorage.setItem("accessToken", accessToken);
    localStorage.setItem("refreshToken", refreshToken);
    localStorage.setItem("fullName", fullName);
    localStorage.setItem("email", email);
    localStorage.setItem("pictureUrl", pictureUrl);

    // tell App.jsx that login happened
    if (onLogin) onLogin();

    navigate("/dashboard");

  }, [navigate, onLogin]);

  return <h2>Logging you in...</h2>;
}
